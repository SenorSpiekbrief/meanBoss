import { HeaderStates } from './header-states';

describe('HeaderStates', () => {
  it('should create an instance', () => {
    expect(new HeaderStates()).toBeTruthy();
  });
});
